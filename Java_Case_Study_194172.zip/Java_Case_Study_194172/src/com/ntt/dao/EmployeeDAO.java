package com.ntt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.ntt.dbcon.ConnectionHolder;
import com.ntt.dbcon.DBConnectionException;
import com.ntt.dbfw.DBFWException;
import com.ntt.dbfw.DBHelper;
import com.ntt.dbfw.ParamMapper;
import com.ntt.domain.Employee;

public class EmployeeDAO {
	public static int insertEmployees(final Employee e1)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper INSERTEMP=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt)
						throws SQLException {
					
					
					preStmt.setString(1, e1.getEnmae());
					preStmt.setString(2, e1.getAddress());
					preStmt.setString(3, e1.getDoj());
					preStmt.setInt(4, e1.getExperience());
					preStmt.setString(5, e1.getDob());
					
					
				}
				
			};
			
		result=DBHelper.executeUpdate(con,SQLMapper.INSERTEMPLOYEE,INSERTEMP);
			
			
		} catch (DBFWException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return result;
		
		
	}//insert
	public static List getDetails() throws DBFWException, EmployeeDAOException, DBConnectionException
	{
		List empDetails=null;
		ConnectionHolder ch=null;
		Connection con=null;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
		//	log.debug("fetchig");
			empDetails=DBHelper.executeSelect(con,SQLMapper.FETCHEMPLOYEE,
					SQLMapper.EMPLOYEEMAPPER);
					
			
		} catch (DBConnectionException e) {
			throw new DBConnectionException("Unable to connect to db");
		
		}
		finally {

			try {

				if (con != null)
					con.close();

			} catch (SQLException e) {
			}
		}
		
		
		return empDetails;
		
	}//view all employee details
	
	public static List getEmpbyId(final int id)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		List empdet=null;
		
		try {
				ch=ConnectionHolder.getInstance();
				con=ch.getConnection();
			final ParamMapper EMPLOYEEMAPPER=new ParamMapper()
			{

				
				public void mapParam(PreparedStatement preStmt) throws SQLException {
				preStmt.setInt(1,id);
				
				
					
				}
				
			};//ananymous class
			
			empdet=DBHelper.executeSelect(con,SQLMapper.FETCHEMPBYID,
				SQLMapper.EMPLOYEEMAPPER, EMPLOYEEMAPPER );
		
			
		
			
		} catch (DBConnectionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empdet;
		
	}//view employee details by empID
	
	public static int deleteEmployee(final int id ) throws DBFWException
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper DELETEEMPLOYEE=new ParamMapper()
					{
				public void mapParam(PreparedStatement preStmt)throws SQLException
				{
					preStmt.setInt(1,id);
				}
				
					};
			
			result=DBHelper.executeUpdate(con,SQLMapper.DELETEEMPLOYEE,DELETEEMPLOYEE);
			
		} catch (DBConnectionException e) {
			// TODO: handle exception
		}
		
		
		return result;
		
		
	}//delete by empid
	public static int updateEmployee(final int id,final String s)
	{
		ConnectionHolder ch=null;
		Connection con=null;
		int result=0;
		
		try {
			ch=ConnectionHolder.getInstance();
			con=ch.getConnection();
			
			final ParamMapper UPDATEEMPLOYEE=new ParamMapper()
					{
				public void mapParam(PreparedStatement preStmt)throws SQLException
				{
					preStmt.setInt(2, id);
					preStmt.setString(1, s);
				}
					};
					result=DBHelper.executeUpdate(con,SQLMapper.UPDATEEMPLOYEE,UPDATEEMPLOYEE);
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return result;
		
		
	}//update employee details by empid

}
