package com.ntt.dao;

import java.sql.ResultSet;

import java.sql.SQLException;

import com.ntt.dbfw.ResultMapper;
import com.ntt.domain.Employee;

public class SQLMapper {
	public static final String FETCHEMPLOYEE="select * from Employee";
	
	public static final String FETCHEMPBYID="select * from Employee where empid=?";
	
	public static final String INSERTEMPLOYEE="insert into Employee(ename,address,doj,experience,dob) values(?,?,?,?,?)";
	
	public static final String DELETEEMPLOYEE="delete from Employee where empid=?";
	
	public static final String UPDATEEMPLOYEE="update Employee set address=? where empid=? ";
	
	
	
	public static final ResultMapper EMPLOYEEMAPPER=
			new ResultMapper()
		{

		
			public Object mapRow(ResultSet rs) throws SQLException {
				
			int id=rs.getInt(1);
			String name=rs.getString(2);
			String address=rs.getString(3);
			String doj=rs.getString(4);
			int exp=rs.getInt(5);
			String dob=rs.getString(6);
			
			Employee e=new Employee(id, name, address, doj, exp, dob);
			
			return e;
			}//mapRow
			
		};//Anonymous class
	

}
