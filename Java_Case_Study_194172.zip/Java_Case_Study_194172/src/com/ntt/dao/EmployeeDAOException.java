package com.ntt.dao;

public class EmployeeDAOException extends Exception {

	public EmployeeDAOException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public EmployeeDAOException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}

