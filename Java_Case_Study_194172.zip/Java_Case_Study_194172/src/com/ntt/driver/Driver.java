package com.ntt.driver;

import java.util.Iterator;

import java.util.List;
import java.util.Scanner;
import com.ntt.dao.EmployeeDAOException;
import com.ntt.dao.EmployeeDAO;
import com.ntt.dbcon.DBConnectionException;
import com.ntt.dbfw.DBFWException;
import com.ntt.domain.Employee;

public class Driver {

	/**
	 * @param args
	 * @throws DBConnectionException 
	 * @throws DBFWException 
	 */
	public static void main(String[] args) throws DBConnectionException, DBFWException {
		// TODO Auto-generated method stub
		List emplist=null;
		int ch=0;
		int status=0;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Welcome to JDBC application to do CRUD ");
		System.out.println("--------------------------------------"+"\n");
		
		System.out.println("Press any digit to continue and zero(0) to exit");
		int ms=sc.nextInt();
		
		if (ms!=0) {
		
		do{
			System.out.println("--MENU--");
			System.out.println("1.Insert Employee Details");
			System.out.println("2.View All Employee Details");
			System.out.println("3.View Employee Details by his ID");
			System.out.println("4.Delete Employee Details by his ID");
			System.out.println("5.Update Employee Details by his ID");
			System.out.println("Enter ur ch");
			ch=sc.nextInt();
			
			switch(ch)
			{
			case 1:
				//inserting
				int result=0;
	
				System.out.println("Enter Employee Name");
				String name=sc.next();

				System.out.println("Enter Employee's Address");
				String address=sc.next();
				
				System.out.println("Enter Date Of Joining");
				String doj=sc.next();
				
				System.out.println("Enter Years Of Experience");
				int experience=sc.nextInt();
				
				System.out.println("Enter Date Of Birth");
				String dob=sc.next();
				
				Employee e1=new Employee(1, name, address, doj, experience, dob);
				
				result=EmployeeDAO.insertEmployees(e1);
				
				
				if(result!=0)
				{
					System.out.println("Employee Details inserted successfully");
				}
				else
				{
					System.out.println("Failed to insert");
				}
				
				break;
			case 2:
				try {
					
					emplist=EmployeeDAO.getDetails();
			
					System.out.println("Details of Employee's are");
					System.out.println("-------------------------");
					for(Iterator it=emplist.iterator();it.hasNext();)
					{
						Employee e2=(Employee)it.next();
						
						System.out.println(e2);
					}				
					
					
				} catch (DBFWException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (EmployeeDAOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
				
			case 3:
				//Geting employee details by passing the employeeId
				List list1=null;
				 sc=new Scanner(System.in);
				System.out.println("\nEnter the Employee id\n");
				int id=sc.nextInt();
				
				list1=EmployeeDAO.getEmpbyId(id);
				
				
				if(!(list1.isEmpty()))
				{
				System.out.println("\n\n**** DETAILS OF Employee  *** \n\n");
				System.out.println("------------------------------------");
				for(Iterator it=list1.iterator();it.hasNext();)
					System.out.println(it.next());
				}
				else
				{
					System.out.println("Inalid employee details");
				}
				break;
				
			
				
			case 4:
				int res=0;
				System.out.println("Enter the Employee id to be deleted");
				 sc=new Scanner(System.in);
				int eid =sc.nextInt();
				res=EmployeeDAO.deleteEmployee(eid);
				if(res!=0)
				{
					System.out.println("Emplyee deleted successfully");
				}
				else
					System.out.println("Invalid Employee ID");
			
				break;
				
			case 5:
				int res1=0;
				sc= new Scanner(System.in);
				System.out.println("Enter The id to be updated");
				int id1=sc.nextInt();
				System.out.println("Enter the employee address to be updated");
				String s1=sc.next();
				res1=EmployeeDAO.updateEmployee(id1, s1);
				if(res1!=0)
				{
					System.out.println("Employee Details Update");
				}
				else
					System.out.println("Invalid Employee ID");
				
				break;
				
				
			}//switch
			System.out.println("\n"+"Do you wish to continue(press any number not zero)");
			status=sc.nextInt();
			
			
		}while(!(status==0));
		
		System.out.println("\n\n Thank You for using Application \n\n");
		}
		
		else
			
		System.out.println("\n\n Thank You for using Application \n\n");
		
		

	}

}
//create table Employee( empid int not null primary key,ename varchar2(30),address varchar2(30),doj date,experience int,dob date);
