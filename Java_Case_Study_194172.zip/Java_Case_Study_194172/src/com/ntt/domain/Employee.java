package com.ntt.domain;

public class Employee {
	
	private int empid;
	private String enmae;
	private String address;
	private String doj;
	private int experience;
	private String dob;
	public Employee(int empid, String enmae, String address, String doj, int experience, String dob) {
		super();
		this.empid = empid;
		this.enmae = enmae;
		this.address = address;
		this.doj = doj;
		this.experience = experience;
		this.dob = dob;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEnmae() {
		return enmae;
	}
	public void setEnmae(String enmae) {
		this.enmae = enmae;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", enmae=" + enmae + ", address=" + address + ", doj=" + doj
				+ ", experience=" + experience + ", dob=" + dob + "]";
	}
	
	
	
	

}
